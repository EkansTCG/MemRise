package com.example.t3project;

import static org.junit.Assert.*;

import org.junit.Test;

/*
    Unit Test (as an example) - Test the correct behavior of the following functions of Deck class
        1. getTitle();
        2. getAuthor();
        3. getDeckid();
    by providing both positive and negative test cases;

    Here is just a demonstration of unit test (for extra credit) :-).
 */
public class DeckTest {
    Deck testDeck1, testDeck2;

    // Method to initialize two instance for tests.
    void setup() {
        testDeck1 = new Deck("deckid1", "uid1", "title1", "author1", null);
        testDeck2 = new Deck("deckid2", "uid2", "title2", "author2", null);
    }
    @Test
    public void getTitle() {
        setup();
        assertTrue("title1".equals(testDeck1.getTitle()));
        assertTrue("title2".equals(testDeck2.getTitle()));
        assertFalse("title1".equals(testDeck2.getTitle()));
    }

    @Test
    public void getAuthor() {
        setup();
        assertTrue("author1".equals(testDeck1.getAuthor()));
        assertTrue("author2".equals(testDeck2.getAuthor()));
        assertFalse("author1".equals(testDeck2.getAuthor()));
    }

    @Test
    public void getDeckId() {
        setup();
        assertTrue("deckid1".equals(testDeck1.getDeckId()));
        assertTrue("deckid2".equals(testDeck2.getDeckId()));
        assertFalse("deckid1".equals(testDeck2.getDeckId()));
    }
}