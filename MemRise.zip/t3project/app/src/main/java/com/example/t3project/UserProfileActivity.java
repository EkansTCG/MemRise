package com.example.t3project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
/*
    UserProfile initializes the user's profile and tracks their level and subject mastery badges
 */
public class UserProfileActivity extends AppCompatActivity {

    ImageView mathBadge, englishBadge, scienceBadge, historyBadge;
    TextView back, level, username, email, mathLevel, englishLevel, historyLevel, scienceLevel;
    ProgressBar progressBar, experienceBar;

    int experienceValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutUserProfile);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();

        level = findViewById(R.id.level);
        back = findViewById(R.id.profileToMain);
        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        progressBar = findViewById(R.id.progressBar4);
        experienceBar = findViewById(R.id.experienceBar);
        mathLevel = findViewById(R.id.mathLevel);
        englishLevel = findViewById(R.id.englishLevel);
        historyLevel = findViewById(R.id.historyLevel);
        scienceLevel = findViewById(R.id.scienceLevel);
        mathBadge = findViewById(R.id.mathBadge);
        englishBadge = findViewById(R.id.englishBadge);
        scienceBadge = findViewById(R.id.scienceBadge);
        historyBadge = findViewById(R.id.historyBadge);

        username.setVisibility(View.GONE);
        email.setVisibility(View.GONE);
        level.setVisibility(View.GONE);
        experienceBar.setVisibility(View.GONE);
        mathLevel.setVisibility(View.GONE);
        englishLevel.setVisibility(View.GONE);
        scienceLevel.setVisibility(View.GONE);
        historyLevel.setVisibility(View.GONE);
        mathBadge.setVisibility(View.GONE);
        englishBadge.setVisibility(View.GONE);
        historyBadge.setVisibility(View.GONE);
        scienceBadge.setVisibility(View.GONE);
        back.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot ds) {
                username.setVisibility(View.VISIBLE);
                email.setVisibility(View.VISIBLE);
                level.setVisibility(View.VISIBLE);
                experienceBar.setVisibility(View.VISIBLE);
                mathLevel.setVisibility(View.VISIBLE);
                englishLevel.setVisibility(View.VISIBLE);
                scienceLevel.setVisibility(View.VISIBLE);
                historyLevel.setVisibility(View.VISIBLE);
                mathBadge.setVisibility(View.VISIBLE);
                englishBadge.setVisibility(View.VISIBLE);
                historyBadge.setVisibility(View.VISIBLE);
                scienceBadge.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
                username.setText(ds.child("username").getValue(String.class));
                email.setText(ds.child("email").getValue(String.class));
                experienceValue = Math.toIntExact(ds.child("experience").getValue(Long.class));

                int math = (Math.toIntExact(ds.child("math").getValue(Long.class)));
                int english = (Math.toIntExact(ds.child("english").getValue(Long.class)));
                int science = (Math.toIntExact(ds.child("science").getValue(Long.class)));
                int history = (Math.toIntExact(ds.child("history").getValue(Long.class)));

                setBadge(mathBadge, math);
                setBadge(englishBadge, english);
                setBadge(scienceBadge, science);
                setBadge(historyBadge, history);

                int levelValue = (int) (experienceValue / 100) + 1;
                experienceBar.setProgress(100 - (levelValue * 100 - experienceValue));
                level.setText("Level: " + levelValue);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.d("UserProfile:", "Can't fetch all decks");
            }
        };
        System.out.println(FirebaseAuth.getInstance().getCurrentUser().getUid());
        FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addListenerForSingleValueEvent(eventListener);

    }

    public void setBadge(ImageView image, int level) {
        switch (level) {
            case 1:
                image.setImageResource(R.drawable.iron);
                break;
            case 2:
                image.setImageResource(R.drawable.bronze);
                break;
            case 3:
                image.setImageResource(R.drawable.silver);
                break;
            case 4:
                image.setImageResource(R.drawable.gold);
                break;
            case 5:
                image.setImageResource(R.drawable.platinum);
                break;
            case 6:
                image.setImageResource(R.drawable.diamond);
                break;
            case 7:
                image.setImageResource(R.drawable.ascendant);
                break;
            case 8:
                image.setImageResource(R.drawable.immortal);
                break;
            case 9:
                image.setImageResource(R.drawable.radiant);
                break;
            case 10:
                image.setImageResource(R.drawable.elysian);
                break;
            case 11:
                image.setImageResource(R.drawable.aurora);
                break;
            case 12:
                image.setImageResource(R.drawable.angelic);
                break;
            default:
                image.setImageResource(R.drawable.question);
                break;
        }
    }
}