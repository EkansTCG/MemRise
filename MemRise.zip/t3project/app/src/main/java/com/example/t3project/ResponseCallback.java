package com.example.t3project;
/*
    ResponseCallback defines the on response and on error.
 */
public interface ResponseCallback {
    void onResponse(String response);
    void onError(Throwable throwable);
}