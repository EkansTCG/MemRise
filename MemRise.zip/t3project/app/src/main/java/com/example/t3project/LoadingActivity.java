//Credits to Yuta Belmont for providing code to read decks from firebase

package com.example.t3project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
/*
    LoadingActivity is the loading screen for public decks activity
 */
public class LoadingActivity extends AppCompatActivity {

    private ArrayList<Deck> allDecks = new ArrayList<>();
    ProgressBar bar;
    private FirebaseAuth mAuth;
    private boolean isGuest = false;
    FirebaseDatabase rootRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading_screen);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutLoading);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();

        bar = findViewById(R.id.pbLoadDecks);
        rootRef = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();

        readAllDecks(rootRef.getReference("Decks"), new PublicDecksActivity.OnGetDataListener() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
            }
            @Override
            public void onFailure() {
            }
        });
    }

    public void readAllDecks(DatabaseReference rr, final PublicDecksActivity.OnGetDataListener listener){
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    String uid = ds.child("uid").getValue(String.class);
                    String author = ds.child("author").getValue(String.class);
                    String title = ds.child("title").getValue(String.class);
                    List<List<String>> cards = (List<List<String>>) ds.child("cards").getValue();
                    String did = ds.child("deckId").getValue(String.class);
                    Deck thisDeck = new Deck(did, uid, title, author, cards);
                    allDecks.add(thisDeck);
                }
                listener.onSuccess(dataSnapshot);
                Intent i = new Intent(LoadingActivity.this, PublicDecksActivity.class);
                i.putExtra("allDecks", allDecks);
                startActivity(i);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.d("MainActivity:", "Can't fetch all decks");
            }
        };
        rr.addListenerForSingleValueEvent(eventListener);
    }

}