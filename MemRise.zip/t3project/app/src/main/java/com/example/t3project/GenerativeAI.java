//Credits to https://ai.google.dev/gemini-api/docs/get-started/android
package com.example.t3project;

import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.Executor;
/*
    GenerativeAI class is the main driver for our quiz feature
 */
public class GenerativeAI {
    String apiKey; //api key dont leak
    GenerativeModel gm;
    GenerativeModelFutures model;
    String resultText;
    public GenerativeAI() {
        apiKey = "AIzaSyBuC0_eVWzvRZamXyzlWCb7N0fZNDite74";
        gm = new GenerativeModel("gemini-pro", apiKey);
        model = GenerativeModelFutures.from(gm);
        resultText = "";
    }

    //generates a response after plugging in a prompt
    public void generate(String prompt, ResponseCallback callback) {
        Content content = new Content.Builder().addText(prompt).build();

        Executor executor = Runnable::run;
        ListenableFuture<GenerateContentResponse> response = model.generateContent(content);

        Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
            @Override
            public void onSuccess(GenerateContentResponse result) {
                resultText = result.getText();
                callback.onResponse(resultText);
            }
            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                callback.onError(t);
            }
        }, executor);
    }
}

//code obtained from google ai dev api
