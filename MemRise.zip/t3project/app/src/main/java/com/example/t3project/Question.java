package com.example.t3project;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
/*
    Question class creates individual quiz questions
 */
public class Question extends AppCompatActivity {

    TextView questionDisplay;
    Button next, A, B, C, D;
    String question, answer;
    int num, tries;
    SharedPreferences sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutQuestion);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();
        questionDisplay = findViewById(R.id.question);
        next = findViewById(R.id.next);
        A = findViewById(R.id.A);
        B = findViewById(R.id.B);
        C = findViewById(R.id.C);
        D = findViewById(R.id.D);

        tries = 0;

        question = getIntent().getStringExtra("question");
        A.setText(getIntent().getStringExtra("A"));
        B.setText(getIntent().getStringExtra("B"));
        C.setText(getIntent().getStringExtra("C"));
        D.setText(getIntent().getStringExtra("D"));
        answer = getIntent().getStringExtra("answer");

        questionDisplay.setText(question);
        next.setVisibility(View.GONE);
        SharedPreferences sharedPref = getSharedPreferences("saveData", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        if(question.contains("1.")) {
            editor.remove("score");
            editor.commit();
        }

        num = sharedPref.getInt("score", 0);
        A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next.setVisibility(View.VISIBLE);
                tries++;
                if (answer.contains("CORRECT ANSWER: A")) {
                    if(tries == 1) {
                        num++;
                    }
                    A.setBackgroundColor(Color.argb(255, 50, 220, 50));
                } else {
                    A.setBackgroundColor(Color.argb(255, 255, 50, 50));
                }
            }
        });

        B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next.setVisibility(View.VISIBLE);
                tries++;
                if (answer.contains("CORRECT ANSWER: B")) {
                    if(tries == 1) {
                        num++;
                    }
                    B.setBackgroundColor(Color.argb(255, 50, 220, 50));
                } else {
                    B.setBackgroundColor(Color.argb(255, 255, 50, 50));
                }
            }
        });

        C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next.setVisibility(View.VISIBLE);
                tries++;
                if (answer.contains("CORRECT ANSWER: C")) {
                    if(tries == 1) {
                        num++;
                    }
                    C.setBackgroundColor(Color.argb(255, 50, 220, 50));
                } else {
                    C.setBackgroundColor(Color.argb(255, 255, 50, 50));
                }
            }
        });

        D.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next.setVisibility(View.VISIBLE);
                tries++;
                if (answer.contains("CORRECT ANSWER: D")) {
                    if(tries == 1) {
                        num++;
                    }
                    D.setBackgroundColor(Color.argb(255, 50, 220, 50));
                } else {
                    D.setBackgroundColor(Color.argb(255, 255, 50, 50));
                }
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getIntent().getBooleanExtra("daily", false)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("M-d-y");
                    Calendar cal = Calendar.getInstance();
                    String dateInStr = sdf.format(cal.getTime());
                    editor.putInt(dateInStr + "score", num);
                }

                editor.putInt("score", num);
                editor.apply();

                System.out.println(getIntent().getIntExtra("grade", 1));
                if(question.contains("10.")) {
                    Intent intent = new Intent(Question.this, QuizScoreActivity.class);
                    intent.putExtra("score", num);
                    intent.putExtra("subject", getIntent().getStringExtra("subject"));
                    intent.putExtra("grade", getIntent().getIntExtra("grade", 1));
                    Question.this.startActivity(intent);
                } else if(!question.contains("10.")){
                    tries = 0;
                    finish();
                }
            }
        });

    }
}
