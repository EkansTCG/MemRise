package com.example.t3project;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.text.SimpleDateFormat;
import java.util.Calendar;
/*
    DailyActivity allows users to take a daily quiz
 */
public class DailyActivity extends AppCompatActivity {

    TextView quest;
    Button start, back, reset, viewScore;
    ProgressBar progress;
    int num;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutDaily);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();

        quest = findViewById(R.id.quest);
        start = findViewById(R.id.startDaily);
        back = findViewById(R.id.backDaily);
        reset = findViewById(R.id.reset);
        progress = findViewById(R.id.progressBar2);
        viewScore = findViewById(R.id.viewscore);

        viewScore.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        num = 0;

        SimpleDateFormat sdf = new SimpleDateFormat("M-d-y");
        Calendar cal = Calendar.getInstance();
        String dateInStr = sdf.format(cal.getTime());

        SharedPreferences pre = getSharedPreferences("saveData", MODE_PRIVATE);
        SharedPreferences.Editor edit = pre.edit();
        //click listener for starting the daily quiz
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!pre.getBoolean(dateInStr, false)){
                    edit.putBoolean(dateInStr, true);
                    edit.commit();
                    progress.setVisibility(View.VISIBLE);
                    generate();
                }
            }
        });
        //click listener for the reset button
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit.clear();
                edit.commit();

                finish();
                startActivity(getIntent());
            }
        });
        viewScore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num = pre.getInt(dateInStr + "score", 0);
                Intent intent = new Intent(DailyActivity.this, QuizScoreActivity.class);
                intent.putExtra("score", num);
                DailyActivity.this.startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    //generates daily
    public void generate() {
        SimpleDateFormat sdf = new SimpleDateFormat("M-d-y");
        Calendar cal = Calendar.getInstance();
        String dateInStr = sdf.format(cal.getTime());

        GenerativeAI gemini = new GenerativeAI();

        //REPLACE THE FIRST SENTENCE TO CHANGE THE QUESTIONS BUT KEEP THE REST SO IT FORMATS CORRECTLY
        gemini.generate("Generate 10 Short Multiple Choice Questions Centered Around A Single Random Subject Of Your Choice With 4 Responses For Each Question And The Correct Answer Indicated, Double Check To Make Sure The Correct Answer Is Actually Correct, Try To First Generate The Question And Answer And Then Add 3 Other Responses, Make Sure There Are Only Line Gaps In Between Problems And Each Question/Response Is Only One Line With No Line Breaks, With the Following Format, Anything In Parenthesis Should Be Replaced By The Value Inside, MAKE SURE DAILY QUIZ AND SUBJECT APPEARS BEFORE EVERY QUESTION AND MAKE SURE YOU DONT ADD NEW LINES UNLESS THERE IS A NEW LINE SYMBOL STATED: Daily Quiz " + dateInStr + "\nSubject:(SUBJECT)\n(QUESTIONNUMBER).(QUESTION)\nA.(ANSWERA)\nB.(ANSWERB)\nC.ANSWERC\nD.(ANSWERD)\nCORRECT ANSWER: (ANSWERCHOICE)\n\n", new ResponseCallback() {
            @Override
            public void onResponse(String response) {
                progress.setVisibility(View.GONE);
                start.setEnabled(true);
                runQuiz(response);
            }

            @Override
            public void onError(Throwable throwable) {
                progress.setVisibility(View.GONE);
                start.setEnabled(true);
                Toast.makeText(DailyActivity.this, "Error: " + throwable.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    //runs daily quiz
    public void runQuiz(String question) {
        System.out.println(question);
        String[] questions = question.split("\n\n");
        for (int i = questions.length-1; i>=0; i--) {
            Intent intent = new Intent(DailyActivity.this, Question.class);
            String lines[] = questions[i].split("\n");
            String text = "";
            for (int j = 0; j < lines.length; j++) {
                if (lines[j].contains("CORRECT")) {
                    intent.putExtra("answer", lines[j]);
                } else if (lines[j].contains("A.")) {
                    intent.putExtra("A", lines[j]);
                } else if (lines[j].contains("B.")) {
                    intent.putExtra("B", lines[j]);
                } else if (lines[j].contains("C.")) {
                    intent.putExtra("C", lines[j]);
                } else if (lines[j].contains("D.")) {
                    intent.putExtra("D", lines[j]);
                } else {
                    text += lines[j] + "\n";
                }
            }
            intent.putExtra("daily", true);
            intent.putExtra("question", text);
            DailyActivity.this.startActivity(intent);
        }
    }

    //overrides resume to change text
    @Override
    public void onResume() {
        super.onResume();

        SimpleDateFormat sdf = new SimpleDateFormat("M-d-y");
        Calendar cal = Calendar.getInstance();
        String dateInStr = sdf.format(cal.getTime());

        SharedPreferences pre = getSharedPreferences("saveData", MODE_PRIVATE);
        SharedPreferences.Editor edit = pre.edit();

        if (pre.getBoolean(dateInStr, false)){
            start.setVisibility(View.GONE);
            viewScore.setVisibility(View.VISIBLE);
            quest.setText(dateInStr + "\n\nYou have already checked in today");
        } else {
            viewScore.setVisibility(View.GONE);
            quest.setText(dateInStr + "\n\nYou have not checked in today! You may do your daily quiz!");
        }
    }
}