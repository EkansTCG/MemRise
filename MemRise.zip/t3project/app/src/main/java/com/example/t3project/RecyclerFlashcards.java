package com.example.t3project;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;
/*
    RecyclerFlashcards is the recycler adapter for the recycler view in public decks activity.
 */
public class RecyclerFlashcards extends RecyclerView.Adapter<RecyclerFlashcards.DataViewHolder> implements Serializable {
    private Context context;
    private ArrayList<Deck> deck;

    //constructor
    public RecyclerFlashcards(ArrayList<Deck> deck, Context context) {
        this.deck = deck;
        this.context = context;
    }

    public static class DataViewHolder extends RecyclerView.ViewHolder {
        private TextView title, author;
        private CardView cardView;
        private ImageView trash;

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            author = itemView.findViewById(R.id.author);
            title = itemView.findViewById(R.id.front);
            trash = itemView.findViewById(R.id.imageView);
            cardView = itemView.findViewById(R.id.cardview);
        }
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_cardview, parent, false);
        return new DataViewHolder((view));
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.title.setText(deck.get(position).getTitle());
        holder.author.setText("By: " + deck.get(deck.size() - 1 - position).getAuthor());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deck.get(position).getCards();
                Intent intent = new Intent(context, ViewCard.class);
                intent.putExtra("Deck", deck.get(position));
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return deck.size();
    }

}
