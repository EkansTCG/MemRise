//Credits are given to Yuta Belmont for loading flashcards through firebase

package com.example.t3project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
/*
    PublicDecksActivity is a recycler view that shows all your decks
 */
public class PublicDecksActivity extends AppCompatActivity {
    ArrayList<Deck> allDecks = new ArrayList<>();
    ArrayList<String> myDeckKeys = new ArrayList<>();
    Map<String, Deck> keyedDecks = new HashMap<>();
    ArrayList<Deck> personalDecks = new ArrayList<>();
    private boolean isGuest = false;
    private boolean inPublic = true;
    FirebaseDatabase rootRef;
    FirebaseAuth mAuth;
    private RecyclerFlashcards recyclerAdapter;
    private ImageView addDeck;
    private TextView myDecks, publicDecks, exit;
    private Button back;
    private SearchView svDecks;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_public_decks);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutPublicDecks);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();

        rootRef = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();
        back = findViewById(R.id.backButton);
        back.setVisibility(View.GONE);

        if ((ArrayList<Deck>) getIntent().getSerializableExtra("allDecks") != null){
            allDecks = (ArrayList<Deck>) getIntent().getSerializableExtra("allDecks");
        }

        //check if current user is a guest:
        isGuest = checkGuest();
        recyclerAdapter = new RecyclerFlashcards(allDecks, PublicDecksActivity.this);
        RecyclerView recycler = findViewById(R.id.rv);
        recycler.setLayoutManager(new LinearLayoutManager(PublicDecksActivity.this));
        recycler.setAdapter(recyclerAdapter);

        if (!isGuest) {
            DatabaseReference thisUser = rootRef.getReference("Users").child(mAuth.getCurrentUser().getUid())
                    .child("MyDecks");
            getUserData(thisUser, new OnGetDataListener() {

                @Override
                public void onSuccess(DataSnapshot dataSnapshot) {
                }

                @Override
                public void onFailure() {
                }
            });
        }


        //get the users decks
        if (!isGuest) {
            Log.d("chk_guest", "not guest");
        }

        svDecks = findViewById(R.id.svSearchPublic);
        myDecks = findViewById(R.id.tvMyDecks);
        publicDecks = findViewById(R.id.tvPublicDecks);
        exit = findViewById(R.id.tvLogout);
        addDeck = findViewById(R.id.abPlusPublic);

        //set logout stuff:
        exit.setTextColor(Color.parseColor("#ff0000"));

        try{
            inPublic = getIntent().getBooleanExtra("isPublic", true);
        }
        catch(Exception e){
        }

        addDeck.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View view) {
                if (isGuest){
                    Toast.makeText(PublicDecksActivity.this, "You must be signed in.", Toast.LENGTH_LONG).show();
                }
                else {
                    LayoutInflater inflater = (LayoutInflater)
                            getSystemService(LAYOUT_INFLATER_SERVICE);
                    View popupView = inflater.inflate(R.layout.activity_create_deck_popup, null);


                    @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView tvPopup = popupView.findViewById(R.id.tvPopup);

//                    recycler.setVisibility(View.GONE);
                    //back.setVisibility(View.VISIBLE);
                    tvPopup.setText("Create Deck?");

                    // create the popup window
                    int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                    int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                    boolean focusable = true; // lets taps outside the popup also dismiss it
                    final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
                    // show the popup window
                    // which view you pass in doesn't matter, it is only used for the window tolken
                    popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
                    popupView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            addCards();
                        }
                    });
                }
            }
        });
        svDecks.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View view) {
                searchPublic();
                Log.d("search", "Clicked");
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View view) {
                back.setVisibility(View.GONE);
                recycler.setVisibility(View.VISIBLE);
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View view) {
                Intent i = new Intent (PublicDecksActivity.this, MemRiseActivity.class);
                startActivity(i);
            }
        });
    }

    public void searchPublic(){
        return;
    }
    public boolean checkGuest(){
        FirebaseUser user = mAuth.getCurrentUser();
        if (user==null){
            return true;
        }
        return false;
    }

    public void addCards(){
        Intent i = new Intent (PublicDecksActivity.this, CreateCardsActivity.class);
        startActivity(i);
    }
    public void restart(){
        Intent i = new Intent (PublicDecksActivity.this, PublicDecksActivity.class);
        startActivity(i);
    }

    public void switchToPublic(){
        inPublic = true;
    }

    public void switchToMine() {
        inPublic = false;
    }

    public void getUserData(DatabaseReference thisUser, final OnGetDataListener listener){
        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot datasnapshot){
                for (DataSnapshot snapshot : datasnapshot.getChildren()){
                    //usr = snapshot.getValue(User.class);
                    String hi = snapshot.getValue(String.class);
                    myDeckKeys.add(hi);
                }
                for (Deck d : allDecks){
                    keyedDecks.put(d.deckId, d);
                }
                //find user specific decks:
                for (String s : myDeckKeys){
                    personalDecks.add(keyedDecks.get(s));
                }
                listener.onSuccess(datasnapshot);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                listener.onFailure();
            }
        };
        thisUser.addListenerForSingleValueEvent(valueEventListener);
    }

    public interface OnGetDataListener {
        //this is for callbacks
        void onSuccess(DataSnapshot dataSnapshot);
        void onFailure();
    }
}
