package com.example.t3project;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;
/*
    RecyclerFlashcards is the recycler adapter for the recycler view in public decks activity.
 */
public class RecyclerLeaderboard extends RecyclerView.Adapter<RecyclerLeaderboard.DataViewHolder> implements Serializable {
    private Context context;
    private ArrayList<User> users;

    //constructor
    public RecyclerLeaderboard(ArrayList<User> users, Context context) {
        this.users = users;
        this.context = context;
    }

    public static class DataViewHolder extends RecyclerView.ViewHolder {
        private TextView title, author;
        private CardView cardView;
        private ImageView trash;

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            author = itemView.findViewById(R.id.author);
            title = itemView.findViewById(R.id.front);
            trash = itemView.findViewById(R.id.imageView);
            cardView = itemView.findViewById(R.id.cardview);
        }
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_cardview, parent, false);
        return new DataViewHolder((view));
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, @SuppressLint("RecyclerView") int position) {
        int levelValue = (int) (users.get(position).getExperience() / 100) + 1;

        holder.title.setText(position+1 + ". " + users.get(position).getUsername());
        holder.author.setText("Level: " + levelValue);

    }

    @Override
    public int getItemCount() {
        return users.size();
    }

}
