//Credits are given to Yuta Belmont for providing code for importing flashcards to and from firebase

package com.example.t3project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;


/*
allows the user to create decks
 */
public class CreateCardsActivity extends AppCompatActivity {
    private List<List<String>> cards = new ArrayList<>();
    private Deck deck = new Deck();
    private TextView tvFront, tvBack, tvDone, tvAdd;
    private EditText edtTitle, edtFront, edtBack;
    private ImageView ivSave, ivAdd;
    private ProgressBar progressBar;
    String deckId, username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        username = user.getDisplayName();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_cards);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutAdd);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();

        tvFront = findViewById(R.id.tvFront);
        tvBack = findViewById(R.id.tvBack);
        tvDone = findViewById(R.id.tvDone);
        tvAdd = findViewById(R.id.tvAddAnother);
        edtTitle = findViewById(R.id.edtAddTitle);
        ivSave = findViewById(R.id.ivSave);
        ivAdd = findViewById(R.id.ivAdd);
        edtFront = findViewById(R.id.edtFront);
        edtBack = findViewById(R.id.edtBack);
        progressBar = findViewById(R.id.pgBar);
        progressBar.setVisibility(View.INVISIBLE);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            //set title name, deck contents
        } else {
            Date date = new Date();
            deckId = String.valueOf(date.getTime());
            deckId = deckId.substring(deckId.length() - 9);
        }

        //adds another card
        ivAdd.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View view) {
                if (!edtFront.getText().toString().equals("") && !edtBack.getText().toString().equals("")) {
                    cards.add(Arrays.asList(new String[]{edtFront.getText().toString(), edtBack.getText().toString()}));
                    edtFront.setText("");
                    edtBack.setText("");
                    edtFront.requestFocus();
                } else {
                    Toast.makeText(CreateCardsActivity.this, "Incomplete card.", Toast.LENGTH_SHORT);
                }
            }
        });

        //adds another card
        tvAdd.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View view) {
                if (!edtFront.getText().toString().equals("") && !edtBack.getText().toString().equals("")) {
                    cards.add(Arrays.asList(new String[]{edtFront.getText().toString(), edtBack.getText().toString()}));
                    edtFront.setText("");
                    edtBack.setText("");
                    edtFront.requestFocus();
                } else {
                    Toast.makeText(CreateCardsActivity.this, "Incomplete card.", Toast.LENGTH_SHORT);
                }
            }
        });

        //saves a deck
        ivSave.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View view) {
                //adds the remaining card to the deck:
                if (!edtFront.getText().toString().equals("") && !edtBack.getText().toString().equals("")) {
                    progressBar.setVisibility(View.VISIBLE);
                    cards.add(Arrays.asList(new String[]{edtFront.getText().toString(), edtBack.getText().toString()}));
                    deck.cards = cards;
                    deck.title = edtTitle.getText().toString();
                    deck.author = username;
                    deck.Uid = FirebaseAuth.getInstance().getUid();
                    deck.deckId = deckId;
                    if (cards.size() == 0) {
                        Intent i = new Intent(CreateCardsActivity.this, PublicDecksActivity.class);
                        i.putExtra("deck", cards.toString());
                        startActivity(i);
                    }

                    //add deck to firebase:
                    FirebaseDatabase.getInstance().getReference("Decks").child(deckId)
                            .setValue(deck).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        FirebaseDatabase.getInstance().getReference("Users").child(deck.Uid).child("MyDecks").child(deckId).setValue(deckId);
                                        Intent i = new Intent(CreateCardsActivity.this, LoadingActivity.class);
                                        startActivity(i);
                                    } else {
                                        Toast.makeText(com.example.t3project.CreateCardsActivity.this, "Failed to upload new deck.", Toast.LENGTH_LONG).show();
                                    }
                                    progressBar.setVisibility(View.GONE);
                                }
                            });
                }
            }
        });

        //saves a deck
        tvDone.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View view) {
                //adds the remaining card to the deck:
                if (!edtFront.getText().toString().equals("") && !edtBack.getText().toString().equals("")) {
                    progressBar.setVisibility(View.VISIBLE);
                    cards.add(Arrays.asList(new String[]{edtFront.getText().toString(), edtBack.getText().toString()}));
                    deck.cards = cards;
                    deck.title = edtTitle.getText().toString();
                    deck.author = username;
                    deck.Uid = FirebaseAuth.getInstance().getUid();
                    deck.deckId = deckId;
                    if (cards.size() == 0) {
                        Intent i = new Intent(CreateCardsActivity.this, LoadingActivity.class);
                        i.putExtra("deck", cards.toString());
                        startActivity(i);
                    }

                    //add deck to firebase:
                    FirebaseDatabase.getInstance().getReference("Decks").child(deckId)
                            .setValue(deck).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        FirebaseDatabase.getInstance().getReference("Users").child(deck.Uid).child("MyDecks").child(deckId).setValue(deckId);
                                        Intent i = new Intent(CreateCardsActivity.this, PublicDecksActivity.class);
                                        startActivity(i);
                                    } else {
                                        Toast.makeText(com.example.t3project.CreateCardsActivity.this, "Failed to upload new deck.", Toast.LENGTH_LONG).show();
                                    }
                                    progressBar.setVisibility(View.GONE);
                                }
                            });
                }
            }
        });
    }
}