package com.example.t3project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
/*
    MemRiseActivity is the home page of our app(after logging in)
 */
public class MemRiseActivity extends AppCompatActivity {

    TextView quiz, title, daily, flashCard, logout, profile, leaderboard, credits;

    private ArrayList<Deck> allDecks = new ArrayList<>();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_mem_rise);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutMemRise);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        System.out.println(mAuth.getCurrentUser());

        quiz = findViewById(R.id.Quiz);
        title = findViewById(R.id.Title);
        flashCard = findViewById(R.id.flashcard);
        daily = findViewById(R.id.daily);
        logout = findViewById(R.id.logout);
        profile = findViewById(R.id.profile);
        leaderboard = findViewById(R.id.leaderboard);
        credits = findViewById(R.id.textView7);


        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            profile.setVisibility(View.GONE);
            logout.setText("Back");
        }

        quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MemRiseActivity.this, QuizActivity.class);
                MemRiseActivity.this.startActivity(intent);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth mAuth = FirebaseAuth.getInstance();
                mAuth.signOut();
                Intent i = new Intent(MemRiseActivity.this, LoginActivity.class);
                i.putExtra("allDecks", allDecks);
                startActivity(i);
            }
        });

        flashCard.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View view) {
                allDecks = (ArrayList<Deck>) getIntent().getSerializableExtra("allDecks");
                Intent intent = new Intent(MemRiseActivity.this, LoadingActivity.class);
                intent.putExtra("allDecks", allDecks);
                MemRiseActivity.this.startActivity(intent);
            }
        });

        daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MemRiseActivity.this, DailyActivity.class);
                MemRiseActivity.this.startActivity(intent);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (FirebaseAuth.getInstance().getCurrentUser() != null) {
                    Intent intent = new Intent(MemRiseActivity.this, UserProfileActivity.class);
                    MemRiseActivity.this.startActivity(intent);
                }
            }
        });

        leaderboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MemRiseActivity.this, LeaderboardActivity.class);
                MemRiseActivity.this.startActivity(intent);
            }
        });
        credits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MemRiseActivity.this, CreditsActivity.class);
                MemRiseActivity.this.startActivity(intent);
            }
        });
    }
}