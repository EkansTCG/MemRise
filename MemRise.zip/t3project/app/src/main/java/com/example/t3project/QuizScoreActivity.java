package com.example.t3project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
/*
    QuizScoreActivity scores the users quizzes.
 */
public class QuizScoreActivity extends AppCompatActivity {
    TextView scoreFraction;
    Button confirm;
    int score;
    double percentage;
    RatingBar rate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_score);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutQuizScore);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();

        scoreFraction = findViewById(R.id.score);
        confirm = findViewById(R.id.confirm);
        rate = findViewById(R.id.ratingBar);

        score = getIntent().getIntExtra("score", 0);
        percentage = (score / 10.0) * 100;
        scoreFraction.setText(score + "/10" );

        if(percentage == 100) {
            rate.setRating(5.00F);
        }
        else if(percentage >= 90) {
            rate.setRating(4.50F);
        }
        else if(percentage >= 80) {
            rate.setRating(4.00F);
        }
        else if(percentage >= 70) {
            rate.setRating(3.50F);
        }
        else if(percentage >= 60) {
            rate.setRating(3.00F);
        }
        else if(percentage >= 50) {
            rate.setRating(2.50F);
        }
        else if(percentage >= 40) {
            rate.setRating(2.00F);
        }
        else if(percentage >= 30) {
            rate.setRating(1.50F);
        }
        else if(percentage >= 20) {
            rate.setRating(1.00F);
        }
        else if(percentage >= 10) {
            rate.setRating(0.50F);
        }
        else {
            rate.setRating(0.00F);
        }

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            FirebaseDatabase.getInstance().getReference("Users")
                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("experience").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if (!task.isSuccessful()) {
                                System.out.println("failed");
                            } else {
                                Long exp = Long.parseLong(String.valueOf(task.getResult().getValue()));
                                System.out.println(exp);
                                FirebaseDatabase.getInstance().getReference("Users")
                                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("experience")
                                        .setValue(exp + (score*10)).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    Toast.makeText(QuizScoreActivity.this, "GAINED " + score + " XP", Toast.LENGTH_LONG).show();
                                                } else {

                                                }
                                            }
                                        });
                            }
                        }
                    });

            if (getIntent().getStringExtra("subject") != null && score >= 9) {
                FirebaseDatabase.getInstance().getReference("Users")
                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(getIntent().getStringExtra("subject")).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                if (!task.isSuccessful()) {
                                    System.out.println("failed");
                                } else {
                                    int exp = Math.toIntExact(Long.parseLong(String.valueOf(task.getResult().getValue())));
                                    int completed = getIntent().getIntExtra("grade", 1);
                                    System.out.println(completed);
                                    if (completed > exp) {
                                        FirebaseDatabase.getInstance().getReference("Users")
                                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(getIntent().getStringExtra("subject"))
                                                .setValue(completed).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            Toast.makeText(QuizScoreActivity.this, "GAINED " + score + " XP", Toast.LENGTH_LONG).show();
                                                        } else {

                                                        }
                                                    }
                                                });
                                    }
                                }
                            }
                        });
            }
        }


        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(QuizScoreActivity.this, MemRiseActivity.class);
                QuizScoreActivity.this.startActivity(intent);
            }
        });

    }
}