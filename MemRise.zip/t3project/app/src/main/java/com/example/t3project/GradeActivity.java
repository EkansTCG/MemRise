package com.example.t3project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/*
  Class for Grade Activity by showing the detail progress and grade;
 */
public class GradeActivity extends AppCompatActivity {
    TextView title;
    Button start, back;
    ProgressBar bar;
    EditText input;
    String subject;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutGrade);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();
        title = findViewById(R.id.title2);
        back = findViewById(R.id.back1);
        bar = findViewById(R.id.progressBar);
        input = findViewById(R.id.editText);
        start = findViewById(R.id.start);

        bar.setVisibility(View.GONE);
        subject = getIntent().getStringExtra("subject");
        title.setText("You selected " + subject + ". Please Enter Your Grade Level (1-12)");


        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Integer.parseInt(input.getText().toString()) >= 1 && Integer.parseInt(input.getText().toString()) <= 12) {
                    bar.setVisibility(View.VISIBLE);
                    input.setEnabled(false);
                    back.setEnabled(false);
                    generate("Grade " + input.getText().toString() + " " + subject);
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    //runs the quiz by splitting the response (check logcat to see where to split)
    public void runQuiz(String question) {
        String[] questions = question.split("\n\n");
        for (int i = questions.length-1; i>=0; i--) {
            Intent intent = new Intent(GradeActivity.this, Question.class);
            String lines[] = questions[i].split("\n");
            String text = "";
            for (int j = 0; j < lines.length; j++) {
                if (lines[j].contains("CORRECT")) {
                    intent.putExtra("answer", lines[j]);
                } else if (lines[j].contains("A.")) {
                    intent.putExtra("A", lines[j]);
                } else if (lines[j].contains("B.")) {
                    intent.putExtra("B", lines[j]);
                } else if (lines[j].contains("C.")) {
                    intent.putExtra("C", lines[j]);
                } else if (lines[j].contains("D.")) {
                    intent.putExtra("D", lines[j]);
                } else {
                    text += lines[j];
                }
            }
            System.out.println(input.getText());
            intent.putExtra("subject", subject.toLowerCase());
            intent.putExtra("grade", Integer.parseInt(input.getText().toString()));
            intent.putExtra("question", text);
            GradeActivity.this.startActivity(intent);
        }
    }

    //generates the quiz (callback)
    public void generate(String prompt) {
        GenerativeAI gemini = new GenerativeAI();

        //REPLACE THE FIRST SENTENCE TO CHANGE THE QUESTIONS BUT KEEP THE REST SO IT FORMATS CORRECTLY
        gemini.generate("Generate 10 Short Multiple Choice Questions For " + prompt + " With 4 Responses For Each Question And The Correct Answer Indicated, Double Check To Make Sure The Correct Answer Is Actually Correct, Try To First Generate The Question And Answer And Then Add 3 Other Responses, Make Sure There Are Only Line Gaps In Between Problems And Each Question/Response Is Only One Line With No Line Breaks, With the Format:\nQUESTIONNUMBER.QUESTION\nA.ANSWERA\nB.ANSWERB\nC.ANSWERC\nD.ANSWERD\nCORRECT ANSWER: ANSWERCHOICE\n\n", new ResponseCallback() {
            @Override
            public void onResponse(String response) {
                bar.setVisibility(View.GONE);
                start.setEnabled(true);
                input.setEnabled(true);
                back.setEnabled(true);
                System.out.println(response);
                runQuiz(response);
            }

            @Override
            public void onError(Throwable throwable) {
                bar.setVisibility(View.GONE);
                start.setEnabled(true);
                input.setEnabled(true);
                back.setEnabled(true);
                Toast.makeText(GradeActivity.this, "Error: " + throwable.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}