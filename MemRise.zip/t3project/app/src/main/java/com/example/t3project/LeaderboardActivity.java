package com.example.t3project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
import java.util.Collections;


import android.widget.TextView;
import android.widget.ProgressBar;

/*
    Leaderboard Activity to show the stack rank of all users.
 */
public class LeaderboardActivity extends AppCompatActivity {

    private TextView back;
    private ArrayList<User> users;
    private RecyclerLeaderboard recyclerAdapter;
    private RecyclerView recycler;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutLeader);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();


        back = findViewById(R.id.leaderboardBack);
        recycler = findViewById(R.id.recyclerLeader);
        progress = findViewById(R.id.progressBar3);
        users = new ArrayList<User>();

        progress.setVisibility(View.VISIBLE);
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                progress.setVisibility(View.GONE);
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    String user = ds.child("username").getValue(String.class);
                    int exp = Math.toIntExact(ds.child("experience").getValue(Long.class));

                    users.add(new User(user, "", new ArrayList<>(), exp));
                    System.out.println(user);
                }

                Collections.sort(users, (User a1, User a2) -> a2.getExperience()-a1.getExperience());

                recyclerAdapter = new RecyclerLeaderboard(users, LeaderboardActivity.this);
                recycler.setLayoutManager(new LinearLayoutManager(LeaderboardActivity.this));
                recycler.setAdapter(recyclerAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("lol");
                Log.d("LeaderBoard:", "Can't fetch users");
            }
        };

        FirebaseDatabase.getInstance().getReference("Users").addListenerForSingleValueEvent(eventListener);

        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
            }
        });
    }
}