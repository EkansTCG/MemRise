package com.example.t3project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

/*
  Activity for taking a quiz.
 */
public class QuizActivity extends AppCompatActivity {

    Button back, Math, English, History, Science;
    ProgressBar bar;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quizactivity);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) ConstraintLayout constraintLayout = findViewById(R.id.ConstraintLayoutQuiz);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(1000);
        animationDrawable.setExitFadeDuration(1000);
        animationDrawable.start();

        back = findViewById(R.id.back);
        bar = findViewById(R.id.progressBar);
        bar.setVisibility(View.GONE);

        Math = findViewById(R.id.Math);
        English = findViewById(R.id.english);
        Science = findViewById(R.id.Quiz);
        History = findViewById(R.id.History);

        Math.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(QuizActivity.this, GradeActivity.class);
                intent.putExtra("subject", "Math");
                QuizActivity.this.startActivity(intent);
            }
        });
        English.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(QuizActivity.this, GradeActivity.class);
                intent.putExtra("subject", "English");
                QuizActivity.this.startActivity(intent);
            }
        });
        History.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(QuizActivity.this, GradeActivity.class);
                intent.putExtra("subject", "History");
                QuizActivity.this.startActivity(intent);
            }
        });
        Science.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(QuizActivity.this, GradeActivity.class);
                intent.putExtra("subject", "Science");
                QuizActivity.this.startActivity(intent);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}