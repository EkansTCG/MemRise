package com.example.t3project;

import java.lang.reflect.Array;
import java.util.ArrayList;
/*
    User class stores all of the user's information.
 */
public class User {
    public String username, email;
    public int experience, math, english, science, history;
    public ArrayList<String> myDecks = new ArrayList<>();

    public User() {

    }

    public User(String username, String email, ArrayList<String> myDecks, int experience) {
        this.username = username;
        this.email = email;
        this.myDecks = myDecks;
        this.experience = experience;
        this.math = 0;
        this.english = 0;
        this.science = 0;
        this.history = 0;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public ArrayList<String> getMyDecks() {
        return myDecks;
    }

    public void setMyDecks(ArrayList<String> myDecks) {
        this.myDecks = myDecks;
    }
}
